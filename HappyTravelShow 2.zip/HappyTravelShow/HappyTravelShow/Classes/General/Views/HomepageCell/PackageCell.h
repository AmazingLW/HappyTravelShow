//
//  PackageCell.h
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/7.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PackageCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *adTitle4lable;
@property (weak, nonatomic) IBOutlet UILabel *asSub4lable;
@property (weak, nonatomic) IBOutlet UIImageView *path4image;


@end
