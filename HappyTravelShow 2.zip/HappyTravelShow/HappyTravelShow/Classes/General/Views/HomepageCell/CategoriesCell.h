//
//  CategoriesCell.h
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/7.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *cate4image;
@property (weak, nonatomic) IBOutlet UILabel *cate4lable;

@end
