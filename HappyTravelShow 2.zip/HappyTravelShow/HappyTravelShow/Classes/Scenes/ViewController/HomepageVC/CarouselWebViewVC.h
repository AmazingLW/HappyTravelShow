//
//  CarouselWebViewVC.h
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/8.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarouselWebViewVC : UIViewController
@property(nonatomic,strong)NSString*url;

@end
