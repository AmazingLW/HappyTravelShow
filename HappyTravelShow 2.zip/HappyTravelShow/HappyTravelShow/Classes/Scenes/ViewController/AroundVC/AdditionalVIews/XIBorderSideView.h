

#import <UIKit/UIKit.h>

@interface XIBorderSideView : UIView

@property (nonatomic, assign) UIRectEdge borderSides;
@property (nonatomic, strong) UIColor *borderColor;
@property (nonatomic, assign) CGFloat borderWidth;
@end