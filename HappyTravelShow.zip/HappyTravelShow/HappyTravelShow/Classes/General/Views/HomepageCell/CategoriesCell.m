//
//  CategoriesCell.m
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/7.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import "CategoriesCell.h"

@implementation CategoriesCell

- (void)awakeFromNib {
    // Initialization code
}

@end
