//
//  MyselfContentCell.h
//  HappyTravelShow
//
//  Created by Amazing on 15/10/9.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>





@interface MyselfContentCell : UITableViewCell

@property(nonatomic,strong) UILabel  *label;
@property(nonatomic,strong) UIImageView  *titleView;





@end
