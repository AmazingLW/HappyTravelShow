//
//  HomepageHeaderModel.h
//  HappyTravelShow
//
//  Created by Amazing on 15/10/6.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomepageHeaderModel : NSObject

@property(nonatomic,strong)NSString *app_picpath,*app_url,*title,*adTitle,*adSubTitle,*n_app_picpath;
@end
