//
//  HomepageScenicModel.h
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/7.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomepageScenicModel : NSObject
@property(nonatomic,strong)NSString*name,*cityCode,*cityId;
@end
