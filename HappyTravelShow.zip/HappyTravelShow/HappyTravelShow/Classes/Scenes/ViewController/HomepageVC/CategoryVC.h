//
//  CategoryVC.h
//  HappyTravelShow
//
//  Created by lanou3g on 15/10/9.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryVC : UIViewController
@property(nonatomic,strong)NSString*urlNum;
@property(nonatomic,strong)NSMutableArray*CityArray;
@property(nonatomic,strong)NSString*CityName,*CityCode;
@end
