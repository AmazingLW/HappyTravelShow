//
//  HomepageVC.h
//  HappyTravelShow
//
//  Created by Amazing on 15/10/6.
//  Copyright (c) 2015年 com.liuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomepageVC : UIViewController
//热门景区,周边城市
@property(nonatomic,strong)NSMutableArray*ScenicArr,*cityArr;
@end
